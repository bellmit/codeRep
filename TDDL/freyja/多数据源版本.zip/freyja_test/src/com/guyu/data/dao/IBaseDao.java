package com.guyu.data.dao;


import com.guyu.data.core.dao.ICoreBaseDao;

public interface IBaseDao  extends ICoreBaseDao {

//	public void saveGoldRecord(GoldRecord gr);

//	public List<Map<String, Object>> findBySql(String sql);

}
