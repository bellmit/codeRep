package com.guyu.core.spring.aop;

public interface BeanSelfAware {
	void setSelf(Object proxyBean);
}
