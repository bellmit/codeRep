package org.freyja.cache.operation;


public class CacheKeysOperation extends FreyjaCacheOperation {

}
