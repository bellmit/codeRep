package org.freyja.cache.operation;


public class CacheSetOperation extends FreyjaCacheOperation {

}
