package org.freyja.cache.operation;


public class CacheListAddOperation extends FreyjaCacheOperation {

}
