package org.freyja.cache.operation;


public class CacheSaveOperation extends FreyjaCacheOperation {

}
