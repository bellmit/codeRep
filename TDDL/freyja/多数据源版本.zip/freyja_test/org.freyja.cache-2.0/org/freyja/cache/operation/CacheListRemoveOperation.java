package org.freyja.cache.operation;


public class CacheListRemoveOperation extends FreyjaCacheOperation {

}
