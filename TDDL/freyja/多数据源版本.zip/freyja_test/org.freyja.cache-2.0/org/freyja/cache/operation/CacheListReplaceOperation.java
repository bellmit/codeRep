package org.freyja.cache.operation;


public class CacheListReplaceOperation extends FreyjaCacheOperation {

}
