package org.freyja.cache.operation;


public class CacheDeleteOperation extends FreyjaCacheOperation {

}
