package org.freyja.cache.operation;


public class CacheGetOperation extends FreyjaCacheOperation {

}
